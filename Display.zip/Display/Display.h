/*
 * Display.h
 *
 * Created: 1/23/2025 7:13:38 PM
 *  Author: Fatima
 */ 


#ifndef DISPLAY_H_
#define DISPLAY_H_

#include <stdint.h>
#include <avr/io.h>
#include <stdint.h>

void display(uint8_t numero);



#endif /* DISPLAY_H_ */